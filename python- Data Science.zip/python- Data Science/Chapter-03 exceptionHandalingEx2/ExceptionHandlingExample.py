'''
Exception handling or error handling:

Exception: is run time error which may or may not occur
Handling : tackle the error when this will occur

Objective of Exception Handling:
-Show user defined/frienldy message
-Prevent the source code/program from failure due to single/few error
-Store the error log

There are following keywords:
-try     : logical code should be written in this block 
-except  : receive or handlle the error message
-finally : is may or may not implemented with try
         : however finally will execute always either error will occur or not
-pass    : is keyword which sliently continue the code without any error message 
-raise   : user defined or custom message 

Note:
    -multiple except block can be implemented with one try
    -try can be implemented without except, then we need to implement finally
    
Exception type/Error Type:
    -ValueError
    -ZeroDivisionError
    -NameError
    
'''

n = int(input('enter data :'))
d = int(input('enter data :'))

try:
    if d<0:
        err = ZeroDivisionError('divisor cannot be less than 0 ')
        raise err 
        
    #div
    o = n/d
    print(o)

except ValueError as e:
    print(e)
except ZeroDivisionError as e:
    print(e)
    
except:
    #print('data is not valid')
    pass
finally:
    print('end of code ')
    
    
#add
s = n+d
print(s)




