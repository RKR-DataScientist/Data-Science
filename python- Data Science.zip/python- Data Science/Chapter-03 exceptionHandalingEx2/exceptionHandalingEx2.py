
while True:
    try:
        
        a = int(input('enter data :'))
        b = int(input('enter data :'))

        c  = a/b
        print(c)
        break

    except:
        print('invalid choice, plz try again !!!')


        
'''
sales = [111,22,3343,'fff','fff','fff',5544566]
Q. wap to get sum of all number and average

'''
sales = [111,22,3343,'f1ff','afff','f0ff',5544566]

x = 0
z=0

for i in range(len(sales)):
    try:
       x = x+int(sales[i])
       z=z+1
    except:
         pass
print(x)
Avg=x/z
print(Avg)




        
