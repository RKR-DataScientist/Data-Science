class taxpayer:

    def Input(a):
        a.name= input("Enter your Name: ")
        a.pan= input(" Enter PAN Number : ")
        a.income= float(input(" Enter your Income :"))
    

    def calctax(b):

        if (b.income <= 100000):
            b.tax=b.income*0
        elif(b.income >= 100001 and b.income <= 200000):
            b.tax= b.income*.10
        elif(b.income >= 200001 and b.income <= 500000):
            b.tax= b.income*.15
        else:
            b.tax= b.income*.20
             
                 
    def dis(b):
        print ("Total Tax Amount: ", b.name)
        print ("Total Tax Amount: ", b.pan)
        print ("Total Tax Amount: ", b.income)
        print ("Total Tax Amount: ", b.tax)


cal= taxpayer()
print(cal)

cal.Input()

cal.calctax()
cal.dis()
