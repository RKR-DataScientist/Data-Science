'''
Module: is also known as package or library (reusable function, class etc)
----------------------------------------------------------------------------
- Module/package is collection of class,functions etc.
There are multiple inbuilt modules or we can create own module/library:
Inbuilts:
    - random : contains multiple function which generate random values
    - math   : contains numeric /arithmetic functions
    - os     : contains function which can get/create manage files and folder
    - shutil : contains function which can move, copy files and folder etc.
    - re   (regular expression) :  pattern matching
    etc.
    
'''
import random
print(random.randint(1000,9999))
print(random.randint(1000,9999))
print(random.random())


import math
print(math.pi)
print(math.factorial(5))
print(math.sqrt(5))


import os
os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training')

f = os.listdir()
print(f)

print(len(f))
c = 0
for x in f:
    #print(x)
    #get count of all .txt file
    #read all text files
    if x.endswith('.txt'):
        c =c+1
        data = open(x)
        print(data.read())

print(c)



        
#move file
import shutil
shutil.move(r'C:\Users\vkumar15\Desktop\Learning & Training\new_file.txt',r'C:\Users\vkumar15\Desktop')
print('file is moved to desktop ')



    
    












