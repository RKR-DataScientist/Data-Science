import TestLibrary
TestLibrary.add(11,444)
TestLibrary.getTime()


#or 
import TestLibrary as l

o = l.tax(1222)
print(o)

#or
from TestLibrary import tax,getTime #import selected functions 
getTime()

#or
from TestLibrary import * #import all functions 
a = tax(11)
print(a)



