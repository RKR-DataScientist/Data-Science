def add(a,b):
    print(a+b)

def tax(amt):
    t = 0
    if amt>10000:
        t = amt*.18
    elif amt>1000:
        t = amt*.12
    elif amt>500:
        t = amt*.05
    else:
        t = amt*.02
    return t


def getTime():
    import time
    lc = time.localtime()
    print(lc)
    
    
