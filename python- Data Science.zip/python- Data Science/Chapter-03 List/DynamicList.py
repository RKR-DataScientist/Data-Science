sale = [] #empty list

for i in range(5):
    x = int(input('enter data :'))
    sale.append(x)


print(sale)

for r in sale:
    print(r)
    


#2 dimenssion list
x = [[11,222,3434],[33,45,55]] # 2 row *3 cols

print(x)
print(x[0])
print(x[0][1])

for r in x:
    print(r)
    

for r in x:
    for c in r:
        print(c)
    

