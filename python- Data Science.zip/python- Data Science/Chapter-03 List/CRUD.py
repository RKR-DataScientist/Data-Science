#CRUD

data = []

while True:

    ch = input('press 1 for add 2 for show 3 for delete 4 for update and 0 for exit')
    if ch=='1':

        d = input('enter data :')
        data.append(d)

    elif ch=='2':
        print(data)
        
    elif ch=='3':
        x = input('enter data to remove')
        if x in data:
            data.remove(x)
            
    elif ch=='4':
        x = input('enter value which you want to update  ')
        for i in range(len(data)):
            if data[i] == x :
                nv = input('enter new value')
                data[i] = nv

                
    elif ch=='0':
        break #stop the loop 
    else:
        print('Invalid choice , plz select again !!!')
        
    
    
        
