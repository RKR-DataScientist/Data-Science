import re

s = input('enter data :')

o = re.match('(.*) are (.*)',s)
print(o)
'''

print(o.groups())
print(o.group(1))
print(o.group(2))
'''

if o:
    print('are is match')
else:
    print('are is not match')



##search
email = input('enter email id:')

#o = re.search('^[a-z]',s)
o = re.search('@gmail.com$',email)
print(o)
if o:
    print('valid gamil account')
else:
    print('invalid gamil account')



  

