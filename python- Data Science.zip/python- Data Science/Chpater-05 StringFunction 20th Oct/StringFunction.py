'''
String Handling:

String Functions:
====================
upper()
lower()
title()   = this is test code = This Is Test Code
capitalize() = this is test code = This is test code 
len()   : return count of chars including space
list()    : break string char by char
split()    : break string by given sepeator / default sperator is space

strip()   : remove leading/extra space
replace()  : find and replace
count()  : return count of given char/word
ord()     : convert char to ASCII (numeric)
       A = 65 , a = 97 , 1 = 49
        65/2 = 1
        32/2 = 0
        16/2 = 0
        8/2  = 0
        4/2  = 0
        2/2  = 0
        1
           1000001 = A  

chr()   : convert numeric to char
endswith() : return boolean (true/false)
isdigit() : return boolean (true/false)
isupper()  : return boolean (true/false)
islower() : return boolean (true/false)
            
slicer     : return string from given index


'''
s = input('enter string ')

#upper()
print(s.upper())

#lower()
print(s.lower())

#title()   = this is test code = This Is Test Code
print(s.title())
#captilize() = this is test code = This is test code
print(s.capitalize())

#len()   : return count of chars including space
print(len(s))


#list()    : break string char by char
o = list(s)
print(o)

#split()    : break string by given sepeator / default sperator is space
o = s.split(' ')
print(o)
print('word count ',len(o))

#strip()   : remove leading/extra space
o = s.strip()
print(o)

#replace()  : find and replace
print(s.replace('a','xy'))

#count()  : return count of given char/word
print(s.count('i'))
print(s.count(' '))
print(s.count('\t'))
print(s.count('\n'))


#ord()     : convert char to ASCII (numeric)
print(ord('A'))
print(chr(67))


              
#endswith() : return boolean (true/false)
if s.endswith('an'):
    print('ending with an')
else:
    print('not ending with an')
    
#isdigit() : return boolean (true/false)
if s.isdigit():
    print('string is number ')
else:
    print('alpha numeric')
    
#isupper()  : return boolean (true/false)
if s.isupper():
    print('string is in upper case')
else:
    print('string in lower case')

    
#islower() : return boolean (true/false)
if s.islower():
    print('string is in lower case')
else:
    print('in upper case ')

    

