import mysql.connector

database = mysql.connector.connect(
  host='localhost',
  user='root',
  passwd="",
  database='dclass',
)

mycursor = database.cursor()

mycursor.execute('select * from dclass')

mycursor.execute('SHOW TABLES')

for x in mycursor:
  print(x)
