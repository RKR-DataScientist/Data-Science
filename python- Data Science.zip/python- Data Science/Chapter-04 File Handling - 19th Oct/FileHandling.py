
data
#print(f)
#print(f.read())

#print(f.readline())
#print(f.readline())
#print(f.readline())

#q. wap to get row count
#q. wap to get char count 
#q. wap to get word count 
o = f.readlines()
print(o)

print('row count :',len(o))

cc = 0
wc =0
for r in o:
    #print(r)
    cc = cc+ len(r)
    wc = wc+len(r.split())


print('char count ',cc)
print('word count ',wc)

f.close()

        





