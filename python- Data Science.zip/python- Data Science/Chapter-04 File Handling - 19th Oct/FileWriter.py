o = open(r'C:\Users\vkumar15\Desktop\out.txt','a') #create new file if not exist

#o.write('hi,this is my test file \n')
#o.write('end\n')

for i in range(5):
    d = input('enter data :')
    o.write(d+'\n')
    
o.close()
