
o=open(r'C:\Users\ravik\Desktop\data.txt','a')
cc=0
wc=0
for r in range(4):
    enter=input('enter data: ')
    o.write(enter+'\n')
    #c=o.readline()

o=open(r'C:\Users\ravik\Desktop\data.txt','r')
c=o.readlines()
print(c)

#for r in 0():
 #   cc=cc+ len(r)
  #  ww=wc+ len(r.split())
#print('char count',cc)
#print('char count',wc)


mc=0
s=0
f=0
fs=0
for r in c:
    c=r.split(',')
    if c[2]=='male':
        mc+=1
        s=s+int(c[3])
    else:
        c[2]=='female'
        fs+=1
        f=f+int(c[3])
print(mc)
print(s)
o.close()
