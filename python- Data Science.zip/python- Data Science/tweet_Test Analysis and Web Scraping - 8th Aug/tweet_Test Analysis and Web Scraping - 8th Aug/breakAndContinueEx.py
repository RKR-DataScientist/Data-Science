for i in range(1,10):  #from 1 to 9 , default incrementer is 1

     print(i)
     

#print odd numbers
for i in range(1,10,2):  #from 1 to 9 

     print(i)
     
#print in reverse
for x in range(10,0,-1):
     print(x)
     
##break
for m in range(1,30):
     if m % 4 == 0:
          break

     print(m)
     
##continue
for m in range(1,10):
     if m % 4 == 0:
          continue

     print(m)

##
print('test')











     
