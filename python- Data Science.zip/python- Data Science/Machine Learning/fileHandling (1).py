o = open(r'C:\Users\sony\Desktop\Python Topics.txt','r') #default is r -read

#print(o.read())

#print(o.readline())
x = o.readlines()
print(x)

#get row count
print(len(x))


#col count
cc= 0
for r in x:
    print(r)
    w = r.split(' ')
    cc += len(w)


print(cc)

