import re # regular expression

import tweepy #access to tweet app , login , pull tweet data 
from tweepy import OAuthHandler #authenication 

from textblob import TextBlob #text/tweet parse, dictionary which return numeric agains every tweet


# keys and tokens from the Twitter Dev Console
consumer_key = 'TL7RyLnfilYH6xaoAlS0XFDCg'
consumer_secret = 'u5uBn4P62PMIxT4uwUVTl1Ycx4rsfByFs6jl2e4SQ9zDjPIzCO'
access_token = '919434545924935681-2woCDEXuXQdhJewDaCRBqHBYmi5SFDN'
access_token_secret = 'T29jqUm6rZqsRYO7AGc47GlgYTaAaN5OtJD0DATo1uBjh'


auth = OAuthHandler(consumer_key, consumer_secret)
# set access token and secret
auth.set_access_token(access_token, access_token_secret)
# create tweepy API object to fetch tweets
api = tweepy.API(auth)

def clean_tweet(tweet):
    
        return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ", tweet).split())

    
def get_tweet_sentiment(tweet):
        '''
        Utility function to classify sentiment of passed tweet
        using textblob's sentiment method
        '''
        # create TextBlob object of passed tweet text
        analysis = TextBlob(clean_tweet(tweet))
        # set sentiment
        if analysis.sentiment.polarity > 0:
            return 'positive'
        elif analysis.sentiment.polarity == 0:
            return 'neutral'
        else:
            return 'negative'
def get_tweet(name,c=10):

    res = api.search(q=name,count=c)
    out = []
    
    for r in res:
        #print(r.text)
        #print(get_tweet_sentiment(r.text))
        out.append(get_tweet_sentiment(r.text))

    return out
                


leaders = ['Narendra Modi','Rahul Gandhi','Sonia Gandhi']
for name in leaders:
    res =get_tweet(name)
    print('------------------',name,'------------------')
    print(res)
    





    




    


        
