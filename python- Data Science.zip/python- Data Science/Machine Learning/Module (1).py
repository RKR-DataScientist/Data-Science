import math


print(math.pi)

print(math.factorial(10))

print(math.sqrt(9))


print(math.pow(3,3))



#import
import os
print(os.getcwd()) #return working directory 

os.chdir(r'C:\Users\sony\Desktop\python\Chapter-01 Example-IfCondition')
print(os.getcwd())


f= os.listdir()

print(f)


for i in f:
    if i.endswith('.txt'):
        print(i)
        file = open(r'C:\Users\sony\Desktop\python\Chapter-01 Example-IfCondition\\'+i)
        print(file.read())
        


        
#shutil
import shutil
#shutil.move(r'C:\Users\sony\Desktop\python\Chapter-01 Example-IfCondition\1-Example.py',r'C:\Users\sony\Desktop\python')



#
import random
print(random.randint(1000,9999))


print(random.random())

print(int(random.random()*10000))


