import tweepy #access to tweet app
from tweepy import OAuthHandler #authenication 


consumer_key = 'TL7RyLnfilYH6xaoAlS0XFDCg'
consumer_secret = 'u5uBn4P62PMIxT4uwUVTl1Ycx4rsfByFs6jl2e4SQ9zDjPIzCO'
access_token = '919434545924935681-2woCDEXuXQdhJewDaCRBqHBYmi5SFDN'
access_token_secret = 'T29jqUm6rZqsRYO7AGc47GlgYTaAaN5OtJD0DATo1uBjh'
        
a= OAuthHandler(consumer_key, consumer_secret)
a.set_access_token(access_token, access_token_secret)
api = tweepy.API(a)

res = api.search(q = 'Narendera Modi', count = 10000)

  
for r in res:
    try:
        
        print(r.text)
    except:
        pass
    
