from tkinter import *


o = Tk()


lfn  = Label(text='Enter first name :')
lfn.pack()
fn = Entry()
fn.pack()

lln = Label(text='Enter last name :')
lln.pack()

ln = Entry()
ln.pack()


msg = Label(text='')
msg.pack()

def click():
    fname = fn.get()
    lname = ln.get()
    name = fname+' '+lname
    
    print('you have clicked on button')
    print('you name is :',name)
    msg.configure(text=name)
    
    
    
submit = Button(text='Submit',command=click)
submit.pack()



o.mainloop()



