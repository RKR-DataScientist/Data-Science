a =1
def test():
    a =10
    global b
    b =1
    print(a)



test()
print(a)
print(b)


