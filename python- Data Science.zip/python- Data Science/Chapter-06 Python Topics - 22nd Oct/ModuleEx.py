import math
import random #generate random number
import CustomModule

print(math.pi)
print(math.factorial(10))
print(random.randint(1,10))


CustomModule.add(11,4)
d = CustomModule.tax(444)
print(d)



#
from CustomModule import *

add(11,3)

#
from CustomModule import add,tax
add(11,3)

#
import CustomModule  as m #create alias 
m.add(22,4)









