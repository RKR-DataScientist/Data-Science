'''
#Question F1
def getData():
    x=int(input("Enter any number: "))
    y=x*x
    print(y)
getData()

#Question F2
def cube():
    x=int(input("Enter any number: "))
    y=x**3
    print(y)
cube()

#Question F3
def area():
    r=int(input("Enter the radius: "))
    areacircle=3.14*r*r
    print(areacircle)
    #return areacircle
area()

#Question F4
def rectangle(l,b):
    area=2*l*b
    print(area)
    return area
rectangle(20,10)

def rectangle():
    l=int(input("Enter the Length of rectangle: "))
    b=int(input("Enter the Length of rectangle: "))
    area=2*l*b
    print(area)
rectangle()



#Question F5
def simpleinterest():
    p=int(input("Enter the principal amount: "))
    r=float(input("Enter the rate percentage: "))
    t=float(input("Enter year or month of debit: "))
    si=p*r*t/100
    print(si)
    return si,p
    
d,p=simpleinterest()
total=d+p
print(total)

#Question F6
def getData():
    x=input("ENter any value or character: ")
    y=ord(x)
    print(y)
getData()


def getData(data):
        d=ord(data)
        print(d)
getData('d')
'''
#Question F7


































