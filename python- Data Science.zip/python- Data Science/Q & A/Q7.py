a=int(input(' Enter the value of a value: '))
b=int(input(' Enter the value of a value: '))
c=int(input(' Enter the value of a value: '))
d=int(input(' Enter the value of a value: '))

if a**3+b**3+c**3==d**3:
  value="match"

else
        value="match"

print(value)
