marks =[]

for a in range (10):
    b=int(input('enter marks:'))
    marks.append(b)

print(marks)
print(max(marks))
print (len(marks))
print (min(marks))
print(sum(marks))

