a=9
b=10
c=11
d=12
e=13
print(a**3)
print(b**3)
print(c**3)
print(d**3)
print(e**3)
    
