a=7
while a<=70:
    print (a)
    a=a+7

b=1
while b<=10:
    print('9','*',b,'=',9*b)
    b=b+1

    
