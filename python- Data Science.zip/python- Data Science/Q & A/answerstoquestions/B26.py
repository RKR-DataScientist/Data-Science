a= int(input('enter choice'))
if a==1:
    Area=3.14*7**2
    print (Area)
elif a==2:
    Area=9*8
    print(Area)

elif a==3:
    Area=(6*7)/2
    print(Area)

