#a=input('roll number')
#b=input('name')
c=int(input('Subject 1 Marks'))
d=int(input('Subject 2 Marks'))
e=int(input('Subject 3 Marks'))
f=int(input('Subject 4 Marks'))
g=int(input('Subject 5 Marks'))
total=c+d+e+f+g
av=total/5
print(total)
print(av)



