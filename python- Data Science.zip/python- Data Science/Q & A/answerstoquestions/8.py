S=int(input('intital Salary:'))

if S>5000 and S<=10000:
    HRA = S*.1
    DA = S*.05
elif S>10000 and S<15000:
    HRA = S*.15
    DA = S*.08
Final = S+HRA+DA    
print('HRA Componenet',HRA)
print('DA Componenet',DA)
print ('Take home Salary',Final)
        
