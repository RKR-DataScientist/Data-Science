a=int(input('a'))
b=int(input('b'))
c=int(input('c'))
d=int(input('d'))
if a**3+b**3+c**3==d**3:
   t='match'
else:
   t='no match'

print(t)
   

   

