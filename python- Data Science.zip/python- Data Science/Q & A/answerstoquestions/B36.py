a=1
SUM=0
while a<=10:
    SUM+=a
    a=a+1

print('sum of first 10 natural number is',SUM)
print('Average of first 10 natural number is',SUM/10)
