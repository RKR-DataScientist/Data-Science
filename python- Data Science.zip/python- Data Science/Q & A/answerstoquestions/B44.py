i=0
while i<50:
    i=i+2
    print(i)
