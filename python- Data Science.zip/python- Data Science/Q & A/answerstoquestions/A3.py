a=9
b=10
c=11
print(a**2)
print(b**2)
print(c**2)
