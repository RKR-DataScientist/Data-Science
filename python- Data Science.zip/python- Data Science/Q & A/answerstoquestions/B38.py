a=0
SUM=0
while a<=10:
    a=a+1
    if a%2==0:
        SUM+=a
print('sum of first 10 even number is',SUM)
print('Average of first 10 even number is',SUM/10)
