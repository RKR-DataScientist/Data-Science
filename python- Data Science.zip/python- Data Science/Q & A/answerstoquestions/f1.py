number=0
def square(a):
    number=a*a
    return a
square(25)
print(square)
