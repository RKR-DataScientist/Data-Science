
while True:

    try:
        
        a=int(input('enter data1'))
        b=int(input('enter data2'))

        s=a/b
        print(s)
    
        break
    except:
        print('data is not correct, plz try again !!!')
        
