i=35
while i<=48:
        i=i+1
        if i%2==0:
            print(i)
