a=int(input('enter numerator'))
b=int(input('enter denominator'))
m=a/b

try:
    if type (m) !=int :
        er=nameError('data format not right')
        raise er
except:
    pass
    
finally:
    print(m)
        
