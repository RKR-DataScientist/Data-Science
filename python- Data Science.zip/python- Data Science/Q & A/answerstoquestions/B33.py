a=1
se=0
while a<=50:
    if a%2==0:
        se+=a
    a+=1
print('sum of even',se)

