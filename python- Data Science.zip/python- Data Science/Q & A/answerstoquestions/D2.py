a=[]
for i in range(5):
    z=int(input('enter the number for array'))
    a.append(z)

n=int(input('enter the number to find in array'))
j=0
for b in a:
    
    if n==b:
        j+=1
    
print(j)
    

    
    
    
