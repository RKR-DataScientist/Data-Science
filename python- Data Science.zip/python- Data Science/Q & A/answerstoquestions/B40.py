a=1
se=0
while a<=20:
    if a%2==0 and a%5!=0 and a%3==0:
        se+=a
    a=a+1
print(se)
    
        
        
        
        
        
