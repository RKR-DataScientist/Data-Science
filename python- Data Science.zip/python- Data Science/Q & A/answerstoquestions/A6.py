a=int(input('length of rectangle'))
b=int(input('breadth of rectangle'))
Area=a*b
perimeter=2*a*b
print('Area of recangle is',Area)
print('Perimeter of rectangle is',perimeter)
      
