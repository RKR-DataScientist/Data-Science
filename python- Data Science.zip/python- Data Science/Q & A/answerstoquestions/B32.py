a=1
b=30
se=0
while a<=b:

    se+=a

    a=a+1
    
print('sum of numbers',se)
print('Average is',se/30)

    


