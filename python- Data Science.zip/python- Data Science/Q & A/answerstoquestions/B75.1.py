#1
n=2
for i in range (8):
    print(n,end=',')
    n=n*2

print()
#2


for i in range(1,41,3):
    print (i,end=',')
    

print()
    
#3
for i in range (1,41,3):
    if i %2==0:
        print(i*-1,end=',')
    
    else:
        print(i,end=',')
print()
#5

for x in range (1,10):
    print('(',end='')
    for c in range(1,x+1):
        if c<x:
            print(c,end='+')
        else:
            print(c,end='')
    print (')+',end='')

print()

#7
for x in range (1,15,2):
    print('(',end='')
    for c in range (1,x+1,2):
        if c<x:
            print(c,end='+')
        else:
            print(c,end='')
    print(')+',end='')
    

