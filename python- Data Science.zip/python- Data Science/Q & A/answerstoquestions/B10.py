c=int(input('unit count'))
f=50
if c<=100:
    t=f+c*.4
elif c>100 and c<=300:
    t=f+40+((c-100)*.5)
elif c>300:
    t=f+(100*.4)+(200*.5)+((c-300)*.6)

print ('Total power bill is Rs',t)

