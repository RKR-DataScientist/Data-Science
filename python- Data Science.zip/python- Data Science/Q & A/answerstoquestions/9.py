S1=int(input('subject 1'))
S2=int(input('subject 2'))
S3=int(input('subject 3'))
S4=int(input('subject 4'))
S5=int(input('subject 5'))

TM = S1+S2+S3+S4+S5
P=TM/5
if P<40:
   Result='Fail'
elif P>40 and P<50:
    Result='Third'
elif P>50 and P<60:
    Result= 'Second'
else:
   Result='First'

print('Student passed with',Result,'division')




             


             


             


             

             
