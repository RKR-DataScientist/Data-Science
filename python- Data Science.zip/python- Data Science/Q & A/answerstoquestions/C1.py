#C1
a=open(r'C:\Users\user\Desktop\Python\Day 6-String function\test.txt','r')
z=a.read()
print(z)
print('Count of space is',z.count(' '))
print('Count of tabs is', z.count('\t'))
print('Count of new line is', z.count('\n'))
#C2
#b='DeLhi Is cAPItal OF InDiA'
#for r in b:
 #   if c[0]== isupper:
        
 

#C3
v='Indians are 1.3 billion'
print(v)
print('word count',len(v))    
    




