r=int(input('radius'))
pie=3.14
area=pie*r**2
print(area)
