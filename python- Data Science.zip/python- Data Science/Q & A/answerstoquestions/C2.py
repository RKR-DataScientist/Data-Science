#C2

a=input('enter data : ')

for i in a:
    if i.isupper():
        print(i.lower(),end='')
    else:
        print(i.upper(),end='')


c = list(a)
for i in c:    
    if i.isupper():
        print(i.lower(),end='')
    else:
        print(i.upper(),end='')
        
   
for i in range(0,len(a)):
    if a[i].isupper():
        print(a[i].lower(),end='')
    else:
        print(a[i].upper(),end='')
