import socket
import random

s = socket.socket()
host = socket.gethostname() # Get local machine name
port = 1234                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

print('plz wait for requrest...')
s.listen(10)                 # Now wait for client connection.
while True:
   c, addr = s.accept()     # Establish connection with client.
   print ('Got connection from', addr) #print ip of client
   otp = random.randint(1000,9999)
   otp=str(otp)
   c.send(otp.encode()) 
   c.close()                # Close the connection
   


