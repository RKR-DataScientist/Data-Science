import threading
import time

def task_1():
    for x in range(1,5):
        print('bill gen')
        time.sleep(2) #wait for 4 secs

def task_2():
    for x in range(1,5):
        print('\tsending')
        time.sleep(2) #wait for 4 secs

t1 = threading.Thread(target=task_1,name='p1')
t2 = threading.Thread(target=task_2,name='p2')

#Synchronizing threads 
#t1.join()
#t2.join()

print(t1.getName())
print(t1.isAlive())
t1.setName('newname')
print(t1.getName())


t1.start()
t2.start()


#task_1()
#task_2()
'''
task_1 1  task_2 1
2 2 
'''

    
    
    

