#for loop
for x in range(10):
    print(x) #print and new line


for x in range(10):
    print(x,end='') #print and don't change line
    


#print in reverse
for x in range(10,0,-1):
    print(x)


#wap to input two number from user and print sum and average of all number
n1 = int(input('enter data :'))
n2 = int(input('enter data :'))
s = 0
for i in range(n1,n2+1):
    #print(i)
    s = s+i

print(s)
print(s/(n2+1-n1))
    
    

    
