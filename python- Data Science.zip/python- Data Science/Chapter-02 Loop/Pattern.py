
n =1
inc = 0

for i in range(10):
    print(n,end=',')
    n = n+4+inc
    inc=inc+2


print()
#6
for x in range(2,20,2):
    print('(',end='')
    for c in range(2,x+1,2):
        if c<x:
            
            print(c,end='+')
        else:
            print(c,end='')
    print(')+',end='')
    #print()
    
    

