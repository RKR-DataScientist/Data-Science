for r in range(0,3):
    for c in range(0,4): 
        print(r,c,end='\t')
    print()#new line 


'''
123
123
123

'''
for r in range(1,4):
    for c in range(1,4): 
        print(c,end='')
    print()#new line 

''''
1
12
123
'''
for r in range(1,10):
    for c in range(1,r+1): 
        print(c,end='')
    print()#new line 

'''
123
12
1
'''
for r in range(3,0,-1):
    for c in range(1,r+1): 
        print(c,end='')
    print()#new line 








