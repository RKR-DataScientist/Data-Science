class cal:

    def add(a,b,c):
        d =b+c
        print(d)

    def mul(a,b,c):
        d = b*c
        print(d)


class dcal(cal):
    def tax(s,amt):
        if amt>1000:
            t = amt*.18
        else:
             t = amt*.05
        return t
    
class st(dcal):
    def test(s):
        print('test')
        
    def add(a,b,c,d):
        d =b+c+d
        print(d)



        
c = st()
c.add(11,34,5) #error 
c.mul(444,4)
o = c.tax(5566)
print(o)
c.test()











